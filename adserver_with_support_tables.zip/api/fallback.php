<?php
// Placeholder for fallback.php
?>