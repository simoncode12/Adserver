<?php
// Placeholder for native.php
?>