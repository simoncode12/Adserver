<?php
// Placeholder for ssp_handler.php
?>