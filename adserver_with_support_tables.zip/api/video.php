<?php
// Placeholder for video.php
?>