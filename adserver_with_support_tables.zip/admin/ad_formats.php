<?php
// Placeholder for ad_formats.php
?>