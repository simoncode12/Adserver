<?php
// Placeholder for templates/sidebar.php
?>