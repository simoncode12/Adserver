<?php
// Placeholder for ssp_endpoints.php
?>