<?php
// Placeholder for rtb_endpoints.php
?>