<?php
// Placeholder for rtb_debug.php
?>