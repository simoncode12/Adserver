<?php
// Placeholder for Seting.php
?>