<?php
// Placeholder for openrtb.php
?>