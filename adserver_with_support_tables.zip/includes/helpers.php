<?php
// Placeholder for helpers.php
?>